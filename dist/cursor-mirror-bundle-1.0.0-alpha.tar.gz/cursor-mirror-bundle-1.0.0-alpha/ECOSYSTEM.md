# The MOOLLM Ecosystem

This bundle is a portable extract from **MOOLLM** — a skill framework that builds on
and extends the Anthropic skill standard.

## What You're Missing

Without full MOOLLM, these features are unavailable:

| Feature | What It Does |
|---------|--------------|
| **K-line Activation** | Saying a protocol name activates related knowledge |
| **Hot/Cold Memory** | Advisory hints for context management |
| **Bootstrap** | Automatic session warmup and context loading |
| **Adventure Mode** | Room-based exploration with narrative evidence |
| **Speed of Light** | Many agents, many turns, one LLM call |
| **Ethical Framing** | Room-based inheritance of performance context |

## MOOLLM's Seven Extensions

1. **Instantiation** — Skills as prototypes that create instances
2. **Three-Tier Persistence** — Platform → Narrative → State
3. **K-lines** — Names that activate knowledge constellations (Minsky)
4. **Empathic Templates** — Smart generation, not string substitution
5. **Speed of Light** — Many agents, many turns, one LLM call
6. **CARD.yml** — Machine-readable interfaces with advertisements
7. **Ethical Framing** — Room-based inheritance of performance context

## Try Full MOOLLM

```bash
git clone https://github.com/leela-ai/moollm.git
cd moollm

# Read the architecture
cat kernel/README.md

# Browse all skills (60+)
cat skills/INDEX.yml

# Bootstrap a session
# (in Cursor) "boot moollm"
```

## The Skill Skill

The `skill` skill teaches you how to create your own skills using the 
**play-learn-lift** methodology:

1. **PLAY** — Explore freely, try things, make mistakes
2. **LEARN** — Notice patterns, document what works
3. **LIFT** — Share wisdom, create reusable skills

cursor-mirror was built this way: exploring Cursor's internals, documenting
patterns, then lifting into a reusable introspection tool.

## Philosophy

> *"The orchestrator is the Operating System. The LLM is the Coherence Engine. 
> The Repo is the Microworld."*

MOOLLM is inspired by:
- **Seymour Papert** — Microworlds, constructionism
- **Marvin Minsky** — Society of Mind, K-lines
- **Dave Ackley** — Robust-first computing
- **The Self Language** — Prototypes and delegation

## Links

- Repository: https://github.com/leela-ai/moollm
- Leela AI: https://leela.ai
